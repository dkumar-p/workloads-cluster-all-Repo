import json
import boto3
import time
import csv
import sys
import shutil
import os
from aux_functions import aux_functions


def ec2_string_cpuutilization(dict_values):
    """It creates CloudWatch widget string to CloudWatch Dashboard of AWS/EC2 namespace metric: CPUUtilization. The data from the EC2 instances is obtained from csv created for this metric in function: list_all_ec2.getListEC2InstancesRunning_For_CloudWatch_Widgets
    
    Parameters
    ----------
    dict_values : str
        Dictionary with the values that it will be used to update cloudwatch dashboard
    
    Returns
    -------
    Str
        String with the widget of AWS/EC2 namespace metric: CPUUtilization
    """
    nombreMetrica='CPUUtilization'
    cluster=dict_values['cluster']
    entorno=dict_values['entorno']
    name=dict_values['name']
    apps=dict_values['apps']
    account=dict_values['account']
    existsTag_GroupComponentGrouping=dict_values['existsTag_GroupComponentGrouping']
    instanceEC2 = dict_values['instanceEC2']
    
    nombreFichero='/tmp/cw_dashboard_ec2_metrics_csv_files/'+nombreMetrica.replace(" ","_")+'.csv'
    with open(nombreFichero, newline='') as csvfile:
       reader = csv.DictReader(csvfile) 
       row_count = sum(1 for row in reader)
       print('Widget '+nombreMetrica+' de EC2 '+instanceEC2+' con '+str(row_count)+' instancias')
       
       #for field in reader.fieldnames:
       #         print(field)
    if row_count > 0:
      i=0
      with open(nombreFichero, newline='') as csvfile:
        reader = csv.DictReader(csvfile)             
        
        cadenaCompleta=""
        for row in reader:
          i=i+1
          dict_values_instance = aux_functions.getTagsFromInstance(row['InstanceId'])
          cadena=""
          cadena=cadena+"""["AWS/EC2", "CPUUtilization", "InstanceId","""
          cadena=cadena+aux_functions.add_quote(dict_values_instance['instanceEC2'])
          cadena=cadena+""", { "accountId" : """+aux_functions.add_quote(account)
          cadena=cadena+""", "label" : """
          cadena=cadena+aux_functions.add_quote(dict_values_instance['name']+" ("+dict_values_instance['instanceEC2']+")")
          if (i<row_count):
            cadena=cadena+"}],"""
          else:  
            cadena=cadena+"}]"""
          cadenaCompleta=cadenaCompleta+cadena
        #print(cadenaCompleta)
    
      stringWidgetCPUUtilization ="""{
            "height": 6,
            "width": 12,
            "x": 0,
            "y": 0,
            "type": "metric",
            "properties": {
                "metrics": ["""
      stringWidgetCPUUtilization =stringWidgetCPUUtilization+cadenaCompleta
      stringWidgetCPUUtilization =stringWidgetCPUUtilization+"""],
                "region": "eu-west-1",
                "stacked": false,
                "title": "EC2 - CPUUtilization",
                "view": "timeSeries"
            }
        }"""     
        
    else:
      stringWidgetCPUUtilization=""
    #print(stringWidgetCPUUtilization)
    return(stringWidgetCPUUtilization)
    
    
def ec2_string_statuscheckfailed(dict_values):
    """It creates CloudWatch widget string to CloudWatch Dashboard of AWS/EC2 namespace metric: StatusCheckFailed_Instance. The data from the EC2 instances is obtained from csv created for this metric in function: list_all_ec2.getListEC2InstancesRunning_For_CloudWatch_Widgets
    
    Parameters
    ----------
    dict_values : str
        Dictionary with the values that it will be used to update cloudwatch dashboard
    
    Returns
    -------
    Str
        String with the widget of AWS/EC2 namespace metric: StatusCheckFailed_Instance
    """
    nombreMetrica='CPUUtilization'
    cluster=dict_values['cluster']
    entorno=dict_values['entorno']
    name=dict_values['name']
    apps=dict_values['apps']
    account=dict_values['account']
    existsTag_GroupComponentGrouping=dict_values['existsTag_GroupComponentGrouping']
    instanceEC2 = dict_values['instanceEC2']
    
    nombreFichero='/tmp/cw_dashboard_ec2_metrics_csv_files/'+nombreMetrica.replace(" ","_")+'.csv'
    with open(nombreFichero, newline='') as csvfile:
       reader = csv.DictReader(csvfile) 
       row_count = sum(1 for row in reader)
       print('Widget StatusCheckFailed_Instance de EC2 '+instanceEC2+' con '+str(row_count)+' instancias')
       
       #for field in reader.fieldnames:
       #         print(field)
    if row_count > 0:
      i=0
      with open(nombreFichero, newline='') as csvfile:
        reader = csv.DictReader(csvfile)             
        
        cadenaCompleta=""
        for row in reader:
          
          i=i+1
          dict_values_instance = aux_functions.getTagsFromInstance(row['InstanceId'])
          cadena=""
          cadena=cadena+"""["AWS/EC2", "StatusCheckFailed_Instance", "InstanceId","""
          cadena=cadena+aux_functions.add_quote(dict_values_instance['instanceEC2'])
          cadena=cadena+""", { "accountId" : """+aux_functions.add_quote(account)
          cadena=cadena+""", "label" : """
          cadena=cadena+aux_functions.add_quote(dict_values_instance['name']+" ("+dict_values_instance['instanceEC2']+")")
          if (i<row_count):
            cadena=cadena+"}],"""
          else:  
            cadena=cadena+"}]"""
          cadenaCompleta=cadenaCompleta+cadena
        #print(cadenaCompleta)
    
      stringWidgetStatusCheckFailed ="""{
            "height": 6,
            "width": 12,
            "x": 12,
            "y": 0,
            "type": "metric",
            "properties": {
                "metrics": ["""
      stringWidgetStatusCheckFailed =stringWidgetStatusCheckFailed+cadenaCompleta
      stringWidgetStatusCheckFailed =stringWidgetStatusCheckFailed+"""],
                "region": "eu-west-1",
                "stacked": false,
                "title": "EC2 - StatusCheckFailed_Instance",
                "view": "singleValue"
            }
        }"""     
        
    else:
      stringWidgetStatusCheckFailed=""
    #print(stringWidgetCPUUtilization)
    return(stringWidgetStatusCheckFailed)
    
    
def ec2_string_network_in_out(dict_values):
    """It creates CloudWatch widget string to CloudWatch Dashboard of AWS/EC2 namespace metrics: NetworkIn and NetworkOut. The data from the EC2 instances is obtained from csv created for this metric in function: list_all_ec2.getListEC2InstancesRunning_For_CloudWatch_Widgets
    
    Parameters
    ----------
    dict_values : str
        Dictionary with the values that it will be used to update cloudwatch dashboard
    
    Returns
    -------
    Str
        String with the widget of AWS/EC2 namespace metrics: NetworkIn and NetworkOut
    """
    nombreMetrica='CPUUtilization'
    cluster=dict_values['cluster']
    entorno=dict_values['entorno']
    name=dict_values['name']
    apps=dict_values['apps']
    account=dict_values['account']
    existsTag_GroupComponentGrouping=dict_values['existsTag_GroupComponentGrouping']
    instanceEC2 = dict_values['instanceEC2']
    
    nombreFichero='/tmp/cw_dashboard_ec2_metrics_csv_files/'+nombreMetrica.replace(" ","_")+'.csv'
    with open(nombreFichero, newline='') as csvfile:
       reader = csv.DictReader(csvfile) 
       row_count = sum(1 for row in reader)
       print('Widgets Network In & Out de EC2 que se van a crear: '+str(row_count))
       
       #for field in reader.fieldnames:
       #         print(field)
    if row_count > 0:
      i=0
      with open(nombreFichero, newline='') as csvfile:
        reader = csv.DictReader(csvfile)             
        
        cadenaCompleta=""
        for row in reader:
          
          i=i+1
          dict_values_instance = aux_functions.getTagsFromInstance(row['InstanceId'])
          #print(dict_values_instance['name']+" ("+dict_values_instance['instanceEC2']+")")
          cadena=""
          cadena=cadena+"""["AWS/EC2", "NetworkIn", "InstanceId","""+aux_functions.add_quote(dict_values_instance['instanceEC2'])+""", { "accountId" : """+aux_functions.add_quote(account)+"""}],"""
          cadena=cadena+"""["AWS/EC2", "NetworkOut", "InstanceId","""+aux_functions.add_quote(dict_values_instance['instanceEC2'])+""", { "accountId" : """+aux_functions.add_quote(account)+"""}]"""
          #cadenaCompleta=cadenaCompleta+cadena
          stringNetworkInOut="""{
            "height": 6,
            "width": 12,
            "x": 12,
            "y": 24,
            "type": "metric",
            "properties": {
                "metrics": ["""
          stringNetworkInOut=stringNetworkInOut+cadena
          stringNetworkInOut=stringNetworkInOut+"""],
                "region": "eu-west-1",
                "stacked": false,
                "title": "EC2 - Network In & Out - """+dict_values_instance['name']+" ("+dict_values_instance['instanceEC2']+""")",
                "view": "timeSeries"
            }
          }"""
          if (i<row_count):
            stringNetworkInOut=stringNetworkInOut+","
          cadenaCompleta=cadenaCompleta+stringNetworkInOut
    else:
      cadenaCompleta=""
    #print(cadenaCompleta)
    return(cadenaCompleta)

    
def ec2_string_network_packets_in_out(dict_values):
    """It creates CloudWatch widget string to CloudWatch Dashboard of AWS/EC2 namespace metrics: NetworkPacketsIn and NetworkPacketsOut. The data from the EC2 instances is obtained from csv created for this metric in function: list_all_ec2.getListEC2InstancesRunning_For_CloudWatch_Widgets
    
    Parameters
    ----------
    dict_values : str
        Dictionary with the values that it will be used to update cloudwatch dashboard
    
    Returns
    -------
    Str
        String with the widget of AWS/EC2 namespace metrics: NetworkPacketsIn and NetworkPacketsOut
    """
    nombreMetrica='CPUUtilization'
    cluster=dict_values['cluster']
    entorno=dict_values['entorno']
    name=dict_values['name']
    apps=dict_values['apps']
    account=dict_values['account']
    existsTag_GroupComponentGrouping=dict_values['existsTag_GroupComponentGrouping']
    instanceEC2 = dict_values['instanceEC2']
    
    nombreFichero='/tmp/cw_dashboard_ec2_metrics_csv_files/'+nombreMetrica.replace(" ","_")+'.csv'
    with open(nombreFichero, newline='') as csvfile:
       reader = csv.DictReader(csvfile) 
       row_count = sum(1 for row in reader)
       print('Widgets Network Packets In & Out de EC2 que se van a crear: '+str(row_count))
       
       #for field in reader.fieldnames:
       #         print(field)
    if row_count > 0:
      i=0
      with open(nombreFichero, newline='') as csvfile:
        reader = csv.DictReader(csvfile)             
        
        cadenaCompleta=""
        for row in reader:
          
          i=i+1
          dict_values_instance = aux_functions.getTagsFromInstance(row['InstanceId'])
          #print(dict_values_instance['name']+" ("+dict_values_instance['instanceEC2']+")")
          cadena=""
          cadena=cadena+"""["AWS/EC2", "NetworkPacketsIn", "InstanceId","""+aux_functions.add_quote(dict_values_instance['instanceEC2'])+""", { "accountId" : """+aux_functions.add_quote(account)+"""}],"""
          cadena=cadena+"""["AWS/EC2", "NetworkPacketsOut", "InstanceId","""+aux_functions.add_quote(dict_values_instance['instanceEC2'])+""", { "accountId" : """+aux_functions.add_quote(account)+"""}]"""
          #cadenaCompleta=cadenaCompleta+cadena
          stringNetworkPacketsInOut="""{
            "height": 6,
            "width": 12,
            "x": 12,
            "y": 36,
            "type": "metric",
            "properties": {
                "metrics": ["""
          stringNetworkPacketsInOut=stringNetworkPacketsInOut+cadena
          stringNetworkPacketsInOut=stringNetworkPacketsInOut+"""],
                "region": "eu-west-1",
                "stacked": false,
                "title": "EC2 - Network Packets In & Out - """+dict_values_instance['name']+" ("+dict_values_instance['instanceEC2']+""")",
                "view": "timeSeries"
            }
          }"""
          if (i<row_count):
            stringNetworkPacketsInOut=stringNetworkPacketsInOut+","
          cadenaCompleta=cadenaCompleta+stringNetworkPacketsInOut
    else:
      cadenaCompleta=""
    #print(stringWidgetCPUUtilization)
    return(cadenaCompleta)
    

