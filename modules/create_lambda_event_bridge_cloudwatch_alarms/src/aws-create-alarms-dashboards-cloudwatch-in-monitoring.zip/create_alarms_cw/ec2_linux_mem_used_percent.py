import json
import boto3
import time
import csv
import sys
import shutil
import os
from aux_functions import create_connection_with_monitoring_account

def create_alarm(dict_values,arnSNSTopic):
    """It creates CloudWatch alarms mem_used_percent from the EC2 instance of the dict and the csv created for this metric in function: aux_functions.listMetrics_from_Cloudwatch_in_AccountResources
    
    Parameters
    ----------
    dict_values : str
        Dictionary with the values that it will be used to delete cloudwatch alarms
    arnSNSTopic : str
        String with the arn of the SNS Topic where the alarms will send the notification when it passed to Alarm state
    
    Returns
    -------
    None
        Create the alarm and print a message
    """
    nombreMetrica='mem_used_percent'
    cluster=dict_values['cluster']
    entorno=dict_values['entorno']
    name=dict_values['name']
    apps=dict_values['apps']
    account=dict_values['account']
    existsTag_GroupComponentGrouping=dict_values['existsTag_GroupComponentGrouping']
    instanceEC2 = dict_values['instanceEC2']
    accountName  = dict_values['accountName']   

    myListOfDictsOfTags = dict_values['myListOfDictsOfTags']
    tagAuxName = 'CloudWatch_Alarm_CWAgent_'+nombreMetrica.replace(" ","_")
    dictName = {'Key': 'Name', 'Value': tagAuxName }
    myListOfDictsOfTags.append(dictName)
    dictIbResourceName = {'Key': 'ib:resource:name', 'Value': tagAuxName}
    myListOfDictsOfTags.append(dictIbResourceName)

    monitoringCloudwatchClient = create_connection_with_monitoring_account.function_asume_role_from_monitoring_account('cloudwatch')
    
    nombreFichero='/tmp/cw_ec2_metrics_csv_files_'+instanceEC2+'/'+instanceEC2+'_'+nombreMetrica.replace(" ","_")+'.csv'
    with open(nombreFichero, newline='') as csvfile:
       reader = csv.DictReader(csvfile) 
       row_count = sum(1 for row in reader)
       print('Alarmas '+nombreMetrica+' de la instancia '+instanceEC2+' que se van a crear: '+str(row_count))
       
       #for field in reader.fieldnames:
       #         print(field)
    if row_count > 0:
      with open(nombreFichero, newline='') as csvfile:
        reader = csv.DictReader(csvfile)             
        for row in reader:
            if (existsTag_GroupComponentGrouping==False): # This instance doesn't belong to an ASG 
                #print('Metricas con valores:'+ row['InstanceId']+'-'+row['InstanceType'])
                app_or_cluster=apps
                app_or_cluster_description=" de la aplicación "+apps

            else:
                #print('Metricas con valores:'+ row['AutoScalingGroupName']+'-'+row['InstanceId']+'-'+row['InstanceType'])
                app_or_cluster=cluster
                app_or_cluster_description=" del cluster "+cluster+" formado por las aplicaciones "+apps    

            if 'AutoScalingGroupName' not in row:
                Dimensions_list= [
                           { 'Name': 'InstanceId','Value': row['InstanceId']},
                           { 'Name': 'InstanceType','Value': row['InstanceType']},
                    ]
            else:
                Dimensions_list= [
                           { 'Name': 'AutoScalingGroupName','Value': row['AutoScalingGroupName']},
                           { 'Name': 'InstanceId','Value': row['InstanceId']},
                           { 'Name': 'InstanceType','Value': row['InstanceType']},
                    ]

            mythreshold=80
            Alarm_Name = "IBERIA-AWS-ALERTAS/"+account+"/ec2/mem_used_percent/"+app_or_cluster+"/"+entorno+"/"+name+"/"+instanceEC2          
            Alarm_Desc = "Parámetro Mem Used Percent de la máquina "+name+"("+instanceEC2+")"+app_or_cluster_description+" en la cuenta de "+accountName+" ("+account+") se encuentra ocupado por encima del "+str(mythreshold)+" %. Avisar a INFRASUP_UTS Office Hours Mon-Fri 10:00 - 18:00"
            
            monitoringCloudwatchClient.put_metric_alarm(
              AlarmName=Alarm_Name,
              AlarmDescription=Alarm_Desc,
              ComparisonOperator='GreaterThanThreshold',
              EvaluationPeriods=2,
              Threshold=mythreshold,
              AlarmActions=[arnSNSTopic,],
              Metrics=[
               {
                 'Id': 'm1',
                 'AccountId': account,
                 'ReturnData': True,
                 'MetricStat': {
                      'Metric': {
                         'Namespace': 'CWAgent',
                         'MetricName': nombreMetrica,
                         'Dimensions': Dimensions_list,
                      },
                      'Period': 300,
                      'Stat': 'Average',
                    },
                 },
              ],
              Tags = myListOfDictsOfTags,
            )
    print('***************')