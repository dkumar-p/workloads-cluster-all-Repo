import json
import boto3
import time
import csv
import sys
import shutil
import os




def getListEC2InstancesRunning_For_CloudWatch_Widgets(custom_filter):   
    """It creates a csv file for each CW Metrics defined in listaNameSpace_Metrica of the EC2 instances in state Running that match with the filter passed by parameter
    
    Parameters
    ----------
    custom_filter : list
        List of dicts that it will be used to filter AWS resources


    
    Returns
    -------
    None
        It creates a CSV files with the dimensions for each CW Metrics define in listaNameSpace_Metric of all EC2 instances in Running state thatget later a Id from the dict dict_values. 
        It an EC2 instance hasn't data from a metric the csv file will have a header line with value 'FicheroVacio'
    """
    clientEC2 = boto3.client('ec2')

    # define the name of the directory to be created
    path = "/tmp/cw_dashboard_ec2_metrics_csv_files"
    
    # define the access rights
    access_rights = 0o755
    
    isExist = os.path.exists(path)
    if (isExist):
        shutil.rmtree(path)   
    try:
        os.mkdir(path, access_rights)
    except OSError:
        print ("Creation of the directory %s failed" % path)
    else:
        print ("Successfully created the directory %s" % path)
        
        
    responseEC2 = clientEC2.describe_instances(Filters=custom_filter)

    #print(responseEC2)
    listaEC2 = []

    #listaEC2.append(instanceEC2)
    for ec2Reservations in responseEC2['Reservations']:
      for ec2Instances in ec2Reservations['Instances']:
        print(ec2Instances['InstanceId']+" state -->"+ec2Instances['State']['Name'])  
        if ec2Instances['State']['Name'] == 'running':
          #print(ec2Instances)
          listaEC2.append(ec2Instances['InstanceId'])
          
    clientAccountResources = boto3.client('cloudwatch')

    # listaNameSpace_Metric should be equal than defined in aux_functions/aux_functions.py in function: listMetrics_from_Cloudwatch_in_AccountResources
    listaNameSpace_Metrica = [['CWAgent','Memory Available Bytes'],['CWAgent','LogicalDisk % Free Space'],['CWAgent','mem_used_percent'],['CWAgent','disk_used_percent'],['AWS/EC2','CPUUtilization'],['Custom','datasource_status'], ['Custom','heap_mem_used_percent'], ['CWAgent','cpu_usage_idle'], ['CWAgent','cpu_usage_iowait'], ['CWAgent','cpu_usage_system'], ['CWAgent','cpu_usage_user'], ['CWAgent','cpu_usage_active'], ['CWAgent','disk_inodes_free'], ['CWAgent','net_err_in'], ['CWAgent','net_err_out'], ['CWAgent','processes_idle'], ['CWAgent','swap_used_percent'] ]

    
    for item in listaNameSpace_Metrica:
      iteracion=0
      listaCompleta=[]
      listaCabecera=[]  
      for idec2 in listaEC2:
         responseAccountResources = clientAccountResources.list_metrics(
                Namespace=item[0],
                MetricName=item[1],
                Dimensions=[{'Name': 'InstanceId', 'Value': idec2}]
            )
         for each_metric in responseAccountResources['Metrics']:
                    if("AutoScalingGroupName" in [x['Name'] for x in each_metric['Dimensions']]): # Its a instance in an ASG
                      if (item[1]=='disk_used_percent'):
                        if (len(each_metric['Dimensions'])!=6):                 
                          continue
                      if (item[1]=='mem_used_percent'):   
                        if (len(each_metric['Dimensions'])!=3):                 
                          continue 
                      if (item[1]=='Memory Available Bytes'):    
                        if (len(each_metric['Dimensions'])!=3):
                         continue             
                      if (item[1]=='LogicalDisk % Free Space'):
                        if (len(each_metric['Dimensions'])!=5):
                          continue  
                    else:     
                      if (item[1]=='disk_used_percent'):
                        if (len(each_metric['Dimensions'])!=5):                 
                          continue
                      if (item[1]=='mem_used_percent'):   
                        if (len(each_metric['Dimensions'])!=2):                 
                          continue 
                      if (item[1]=='Memory Available Bytes'):    
                        if (len(each_metric['Dimensions'])!=2):
                         continue             
                      if (item[1]=='LogicalDisk % Free Space'):
                        if (len(each_metric['Dimensions'])!=4):
                          continue  
                    """           
                    if (existsTag_GroupComponentGrouping==False): #False
                      if (item[1]=='disk_used_percent'):
                        if (len(each_metric['Dimensions'])!=5):                 
                          continue
                      if (item[1]=='mem_used_percent'):   
                        if (len(each_metric['Dimensions'])!=2):                 
                          continue 
                      if (item[1]=='Memory Available Bytes'):    
                        if (len(each_metric['Dimensions'])!=2):
                         continue             
                      if (item[1]=='LogicalDisk % Free Space'):
                        if (len(each_metric['Dimensions'])!=4):
                          continue  
                    else:  # Its a instance in an ASG
                      if (item[1]=='disk_used_percent'):
                        if (len(each_metric['Dimensions'])!=6):                 
                          continue
                      if (item[1]=='mem_used_percent'):   
                        if (len(each_metric['Dimensions'])!=3):                 
                          continue 
                      if (item[1]=='Memory Available Bytes'):    
                        if (len(each_metric['Dimensions'])!=3):
                         continue             
                      if (item[1]=='LogicalDisk % Free Space'):
                        if (len(each_metric['Dimensions'])!=5):
                          continue  

                    """    
                    listaElementos = []
                    listaCabecera = []
                  
                      #print(each_metric['Dimensions'])
                    for each_dimensions in each_metric['Dimensions']:
                            
                        listaElementos.append(each_dimensions['Value'])
                        listaCabecera.append(each_dimensions['Name'])
                    listaCompleta.append(listaElementos)
                    #print(listaCabecera)    
                     #listaCompleta.append(cabecera)
                     #listaCompleta.append(resto)    
    
                     #print(resto)   
       
      if (len(listaCabecera)==0):
           listaCabecera.append('FicheroVacio')          
    
      listaCompleta.insert(0,listaCabecera) 
    
      nombreMetrica = item[1].replace(" ","_")
      nombreFichero = nombreMetrica+'.csv'
      directorio='/tmp/cw_dashboard_ec2_metrics_csv_files/'
      #print (nombreMetrica+"-->"+idec2+"-->"+listaCabecera[0])
         #with open(directorio+nombreFichero) as f:
         #  print (sum(1 for _ in f)    
           
      with open(directorio+nombreFichero, 'a+', newline ='') as f:
             write = csv.writer(f)
             write.writerows(listaCompleta)    
      print("Fichero "+directorio+nombreFichero+" generado correctamente")  
    print("####################")