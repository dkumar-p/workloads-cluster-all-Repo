import json
import boto3
import time
import csv
import sys
import shutil
import os
from aux_functions import aux_functions

def getArnLoadBalancers(dict_values):  
  """It gets the arn form the Load Balancers that matches with the filter
    
  Parameters
  ----------
  dict_values : str
      Dictionary with the values that it will be used to create/delete cloudwatch alarms

    
  Returns
  -------
  List
      List with the arns of the Load Balancers that matches the conditions
  """
  clientTagApi = boto3.client('resourcegroupstaggingapi')
  custom_filter = aux_functions.getCustomFilter(dict_values)

  if (custom_filter[0]['Name'] == 'tag:group:component-grouping'):
      tagFilter1= { 'Key': "group:component-grouping", 'Values': custom_filter[0]['Values'] }
  else:
      tagFilter1= { 'Key': "ib:resource:application", 'Values': custom_filter[0]['Values'] }
   
   
  tagFilter2= { 'Key': "ib:resource:environment", 'Values': custom_filter[1]['Values'] }
    
  filter = []
  filter.append(tagFilter1)
  filter.append(tagFilter2)
  responseTagApi = clientTagApi.get_resources(ResourceTypeFilters=['elasticloadbalancing:loadbalancer',], TagFilters= filter)
  #print(responseTagApi['ResourceTagMappingList'])
  resultadoALBs = []
  if (len(responseTagApi['ResourceTagMappingList'])>0):
      for alb in responseTagApi['ResourceTagMappingList']:
          resultadoALBs.append(alb['ResourceARN'])
      return resultadoALBs
  else:
     print('There are not ALBs in this account for the filter '+json.dumps(tagFilter1)+' and '+json.dumps(tagFilter2))
     return resultadoALBs
     
     
def getArnTargetGroups(dict_values):  
  """It gets the arn form the Target Groups that matches with the filter
    
  Parameters
  ----------
  dict_values : str
      Dictionary with the values that it will be used to create/delete cloudwatch alarms

    
  Returns
  -------
  List
      List with the arns of the Target Groups that matches the conditions
  """
  clientTagApi = boto3.client('resourcegroupstaggingapi')
  custom_filter = aux_functions.getCustomFilter(dict_values)

  if (custom_filter[0]['Name'] == 'tag:group:component-grouping'):
      tagFilter1= { 'Key': "group:component-grouping", 'Values': custom_filter[0]['Values'] }
  else:
      tagFilter1= { 'Key': "ib:resource:application", 'Values': custom_filter[0]['Values'] }
  
  tagFilter2= { 'Key': "ib:resource:environment", 'Values': custom_filter[1]['Values'] }
   
  filter = []
  filter.append(tagFilter1)
  filter.append(tagFilter2)
  responseTagApi = clientTagApi.get_resources(ResourceTypeFilters=['elasticloadbalancing:targetgroup',], TagFilters= filter)
  #print(responseTagApi['ResourceTagMappingList'])
  resultadoTGs = []
  if (len(responseTagApi['ResourceTagMappingList'])>0):
      
      for tg in responseTagApi['ResourceTagMappingList']:
          resultadoTGs.append(tg['ResourceARN'])
      return resultadoTGs
  else:
     print('There are not Target Groups in this account for the filter '+json.dumps(tagFilter1)+' and '+json.dumps(tagFilter1))
     return resultadoTGs

def getAplicationLoadBalancerName(listLB):
    """From a list of Arns of Load Balancer it creates a list of name of Load Balancers
    
    Parameters
    ----------
    listLB : str
        List of Arns of Load Balancers

    
    Returns
    -------
    List
        List with the names of the Load Balancers
    """
    alb_name = []
    for lb in listLB:
        lb_name = lb.split(":loadbalancer/")[1]
        if(lb_name[:3]=='app'):
            alb_name.append(lb_name)
    return alb_name
    
def getTargetGroupName(listTG):
    """From a list of Arns of Target Groups it creates a list of names of Target Groups
    
    Parameters
    ----------
    listTG : str
        List of Arns of Target Groups

    
    Returns
    -------
    List
        List with the names of the Target Groups
    """
    tg_name = []
    for tg in listTG:
        tgname = tg.split(":targetgroup/")[1]
        tg_name.append(tgname)
    return tg_name

def asociarALBvsTG(listALB,listTG):
    """From a list of names of ALB and a list of names of Target Groups it creates a list of dictionarys with long and short name of TG and ALB to create widgets in CloudWatch Dashboards
    
    Parameters
    ----------
    listALB : str
        List of names of Application Load Balancers
    listTG : str
        List of names of Target Groups
    
    Returns
    -------
    List
        List of dictionarys with the long and short name of the Target Groups and Application Load Balancer to create widgets in CloudWatch Dashboards
    """
    listaALBvsTG = []
    for alb in listALB:
        for tg in listTG:
            a = alb.split('/')[1]
            if (a in tg):
                #print(alb+'*******'+tg+'***')
                my_dict = {'alb_name':alb, 'tg_name': 'targetgroup/'+tg, 'alb_corto': alb.split('/')[1], 'tg_corto': tg.split('/')[0]}
                listaALBvsTG.append(my_dict)
    #print(listaALBvsTG)
    return(listaALBvsTG)

def createList_Alb_vs_TG(dict_values):
    """From a dict with the values from an EC2 instance, creates a list of dictionarys with the long and short name of the Target Groups and Application Load Balancer to create widgets in CloudWatch Dashboards
    
    Parameters
    ----------
    dict_values : str
        Dictionary with the values that it will be used to delete cloudwatch alarms

    
    Returns
    -------
    List
        List of dictionarys with the long and short name of the Target Groups and Application Load Balancer to create widgets in CloudWatch Dashboards
    """
    alb_list = getAplicationLoadBalancerName(getArnLoadBalancers(dict_values))
    #print(alb_list_arn)
    tg_list = getTargetGroupName(getArnTargetGroups(dict_values))
    #print(tg_list_arn)
    return asociarALBvsTG(alb_list,tg_list)
