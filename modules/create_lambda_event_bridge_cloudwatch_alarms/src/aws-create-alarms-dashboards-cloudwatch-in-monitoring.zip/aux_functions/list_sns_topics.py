import json
import boto3
import time
import csv
import sys
import shutil
import os
from aux_functions import aux_functions
from aux_functions import create_connection_with_monitoring_account

def getArnSNSTopic_from_monitoring(dict_values):  
  """It gets the arn form the SNS Topic that matches with the filter
    
  Parameters
  ----------
  dict_values : str
      Dictionary with the values that it will be used to create/delete cloudwatch alarms

    
  Returns
  -------
  Dict
      Dictionary with a boolean and a string with the arn of the SNS Topic that matches the conditions  or a message
  """
  clientTagApi = create_connection_with_monitoring_account.function_asume_role_from_monitoring_account('resourcegroupstaggingapi')
  custom_filter = aux_functions.getCustomFilter(dict_values)

  if (custom_filter[0]['Name'] == 'tag:group:component-grouping'):
      tagFilter1= { 'Key': "group:component-grouping", 'Values': custom_filter[0]['Values'] }
  else:
      tagFilter1= { 'Key': "ib:resource:application", 'Values': custom_filter[0]['Values'] }
   
  tagFilter2= { 'Key': "ib:resource:environment", 'Values': custom_filter[1]['Values'] }
  
  filter = []
  filter.append(tagFilter1)
  filter.append(tagFilter2)

  responseTagApi = clientTagApi.get_resources(ResourceTypeFilters=['sns:topic',], TagFilters= filter)
  #print(responseTagApi['ResourceTagMappingList'])
  dict_Resultado = {}
  if (len(responseTagApi['ResourceTagMappingList'])>0):
     #print(responseTagApi['ResourceTagMappingList'][0]['ResourceARN'])
     dict_Resultado['existsSNSTopic']=True
     dict_Resultado['SnsTopicArn']=responseTagApi['ResourceTagMappingList'][0]['ResourceARN']
     return dict_Resultado
  else:
     dict_Resultado['existsSNSTopic']=False
     dict_Resultado['SnsTopicArn']='There are not SNS topic in Monitoring Accounto with the filter '+json.dumps(tagFilter1)+' and '+json.dumps(tagFilter2)
     return dict_Resultado