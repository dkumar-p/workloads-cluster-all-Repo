import json
import boto3
import time
import csv
import sys
import shutil
import os
from aux_functions import aux_functions

def getArnRDS(dict_values): 
  """It gets the arn form the RDSs that matches with the filter
    
  Parameters
  ----------
  dict_values : str
      Dictionary with the values that it will be used to create/delete cloudwatch alarms

    
  Returns
  -------
  List
      List with the arns of the RDSs that matches the conditions
  """ 
  clientTagApi = boto3.client('resourcegroupstaggingapi')
  custom_filter = aux_functions.getCustomFilter(dict_values)

  if (custom_filter[0]['Name'] == 'tag:group:component-grouping'):
      tagFilter1= { 'Key': "group:component-grouping", 'Values': custom_filter[0]['Values'] }
  else:
      tagFilter1= { 'Key': "ib:resource:application", 'Values': custom_filter[0]['Values'] }
   
  #tagFilter1= { 'Key': "group:component-grouping", 'Values': ['backoffice-people--sla3--ews--infra-8022'] } 
   
  tagFilter2= { 'Key': "ib:resource:environment", 'Values': custom_filter[1]['Values'] }
  #tagFilter2= { 'Key': "ib:resource:environment", 'Values': ['prod'] }    
  filter = []
  filter.append(tagFilter1)
  filter.append(tagFilter2)
  responseTagApi = clientTagApi.get_resources(ResourceTypeFilters=['rds:db',], TagFilters= filter)
  resultadoRDSs = []
  if (len(responseTagApi['ResourceTagMappingList'])>0):
      
      for alb in responseTagApi['ResourceTagMappingList']:
          resultadoRDSs.append(alb['ResourceARN'])
          #print(resultadoRDSs)
      return resultadoRDSs
  else:
     print('No hay RDS en esta cuenta para el filtro '+json.dumps(tagFilter1)+' y '+json.dumps(tagFilter2))
     return resultadoRDSs
     
     
def getRDSName(listRDS):
    """From a list of Arns of RDSs it creates a list of name of RDS
    
    Parameters
    ----------
    listLB : str
        List of Arns of RDSs

    
    Returns
    -------
    List
        List with the names of the RDSs
    """
    rds_name = []
    for rds in listRDS:
        rdsname = rds.split(":db:")[1]
        rds_name.append(rdsname)
    #print(rds_name)
    return rds_name
    
