import boto3


def function_asume_role_from_monitoring_account(AWS_service):
    """It creates a dict with some tags from the instance
    
    Parameters
    ----------
    AWS_service : str
        Parameter AWS_service that will be launched in Monitoring account(cloudwatch or resourcegroupstaggingapi)

    
    Returns
    -------
    dict
        Dictionary with key/values from the EC2 instance that will be used to create alarms and the dashboard
    """
    sts_connection = boto3.client('sts')
    cuentaMonitoring = sts_connection.assume_role(
        RoleArn = "arn:aws:iam::207656073076:role/aws-lambdaCreateAlarmsAndDashboardsGetTags-Role",
        RoleSessionName = "cross_acct_lambda"
    )
    ACCESS_KEY= cuentaMonitoring['Credentials']['AccessKeyId']
    SECRET_KEY= cuentaMonitoring['Credentials']['SecretAccessKey']
    SESSION_TOKEN= cuentaMonitoring['Credentials']['SessionToken']    
    return boto3.client(AWS_service, aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY, aws_session_token=SESSION_TOKEN)