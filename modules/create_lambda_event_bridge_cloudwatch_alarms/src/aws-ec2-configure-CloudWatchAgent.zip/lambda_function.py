import json
import boto3
import time
import csv
import sys
import shutil
import os


    
def lambda_handler(event, context):

    #print(event)
    #print(event['source']+'--->'+event['detail-type']+'-->'+event['account'])
    instanceEC2=""
    state=""
    account=""
    
    if ('source' in event):
      if (event['source'] == "aws.ec2"):
        if ('detail-type' in event): 
            if (event['detail-type'] == "EC2 Instance State-change Notification"):
              print(event)
              instanceEC2 = event['detail']['instance-id']
              state = event['detail']['state']
              account = event['account']
            else:
              message='Invalid event, detail-type key does not have  `EC2 Instance State-change Notification` value.'
              print(message)
              return {
                 'statusCode': 200,
                 'body': message      
              } 
        else:
            message='Invalid event, detail-type key does not exist.'
            print(message)
            return {
                 'statusCode': 200,
                 'body': message      
            } 
      else:
        message='Invalid event, source key does not have `aws.ec2` value.'
        print(message)
        return {
                 'statusCode': 200,
                 'body': message      
        } 
    else:
        message='Invalid event, source key does not exist.'
        print(message)
        return {
                 'statusCode': 200,
                 'body': message      
        } 

    if (state not in ["running","terminated"]):
        message='State: '+state+' is not admited'
        print(message)
        return {
                 'statusCode': 200,
                 'body': message      
        }

    if (instanceEC2==''):
        message='Invalid Instance Id'
        print(message)
        return {
                 'statusCode': 200,
                 'body': message      
        } 

    if (account==''):
        message='Invalid Account number'
        print(message)
        return {
                 'statusCode': 200,
                 'body': message      
        } 


    validateEC2Instance = exist_Tag_in_EC2(instanceEC2,'validateEC2Instance') 
    if (validateEC2Instance is not None):
      if('statusCode' in validateEC2Instance):
         return validateEC2Instance

    validateTagGroupOrApplication = exist_Tag_in_EC2(instanceEC2,'validate_groupcomponentgrouping_o_ibresourceapplication')
    validateTagIbResourceEnvironment = exist_Tag_in_EC2(instanceEC2,'ib:resource:environment')
    validateTagMonitoring = exist_Tag_in_EC2(instanceEC2,'ib:resource:monitoring')
    validateTagIbAccountName = exist_Tag_in_EC2(instanceEC2,'ib:account:name')
    validateTagIbResourceLetterEv = exist_Tag_in_EC2(instanceEC2,'ib:resource:letter-ev')
    if (validateTagMonitoring and validateTagGroupOrApplication and validateTagIbResourceEnvironment and validateTagIbAccountName and validateTagIbResourceLetterEv):
        if (state=='running'):
            print('****************')
            print(instanceEC2)
            print('****************')    
            clientEC2 = boto3.client('ec2')
            status = clientEC2.describe_instance_status(InstanceIds=[instanceEC2])

    
            instanceStatus=status['InstanceStatuses'][0]['InstanceStatus']['Status']
            systemStatus=status['InstanceStatuses'][0]['SystemStatus']['Status']
            estado=False
            i=0
            while (estado==False):
               status = clientEC2.describe_instance_status(InstanceIds=[instanceEC2])
               instanceStatus=status['InstanceStatuses'][0]['InstanceStatus']['Status']
               systemStatus=status['InstanceStatuses'][0]['SystemStatus']['Status']   
               print("Estado de la instancia:"+status['InstanceStatuses'][0]['InstanceStatus']['Status']+'. Estado del sistema:'+status['InstanceStatuses'][0]['SystemStatus']['Status'])
               if(instanceStatus=='ok' and systemStatus=='ok'):
                   estado=True
               else:
                   time.sleep(5)
                   i=i+1
            print('We have waited '+str(i*5)+' seconds')  
            time.sleep(20)

        

            document_CloudWatch_Agent_Install(instanceEC2)
            document_CloudWatch_ManageAgent_no_proxy(instanceEC2)
            document_cloudWatch_agent_configure_metrics_logs_jboss_apps(instanceEC2, 'Ib-CloudWatch-ManageAgent-Generic-Metrics','CloudWatch-Agent-metrics',1)
            document_cloudWatch_agent_configure_metrics_logs_jboss_apps(instanceEC2, 'Ib-CloudWatch-ManageAgent-Generic-Logs','CloudWatch-Agent-logs',2)
            validateTagResourceAppType = exist_Tag_in_EC2(instanceEC2, 'ib:resource:apptype')
            if (validateTagResourceAppType):
                document_cloudWatch_agent_configure_metrics_logs_jboss_apps(instanceEC2, 'AmazonCloudWatch-ManageAgent','CloudWatch-Agent-logs-jboss-apps-1',3 )
                document_cloudWatch_agent_configure_metrics_logs_jboss_apps(instanceEC2, 'AmazonCloudWatch-ManageAgent','CloudWatch-Agent-logs-jboss-apps-2',4 )
    else:
           message='ERROR: Instance: '+instanceEC2+" does not have one of these options defined: ib:resource:monitoring, ib:resource:environment or one between group:component-grouping or ib:resource:application"
           print(message)
           return {
                 'statusCode': 200,
                 'body': message      
           }
           
    inputForInvoker = {
        'instanceEC2': instanceEC2,
        'state': state,
        'account':account,
    }
    clientLambda=boto3.client('lambda')
    response = clientLambda.invoke(
        FunctionName='arn:aws:lambda:eu-west-1:'+account+':function:aws-create-alarms-dashboards-cloudwatch-in-monitoring',
        #InvocationType='RequestResponse', #Event
        InvocationType='Event',
        Payload=json.dumps(inputForInvoker)
    )
    

    message="The Cloudwatch Agent was sucesfully installed and configured"
    return {
        'statusCode': 200,
        'body': message
    }

         
def document_CloudWatch_Agent_Install(instanceEC2):
    """It launchs SSM Document to install CloudWatch Agent in an EC2 instance
    
    Parameters
    ----------
    instanceEC2 : str
        Parameter Instance Id of an EC2 Instance

    Returns
    -------
    None
        Print a message and the response to the executed process
    """
    ssm = boto3.client('ssm')
    response = ssm.send_command(
        InstanceIds = [instanceEC2],
        DocumentName='AWS-ConfigureAWSPackage',
        Parameters={'action':['Install'],'installationType':['Uninstall and reinstall'],'name':['AmazonCloudWatchAgent']},
        CloudWatchOutputConfig={
            'CloudWatchLogGroupName': 'aws-systemsmanager/maintenance-cloudwatch-agent',
            'CloudWatchOutputEnabled': True
         }
        )
    command_id = response["Command"]["CommandId"]
    time.sleep(5)
    output = ssm.get_command_invocation(
            CommandId=command_id,
            InstanceId=instanceEC2
            )
            
    print('***document_CloudWatch-Agent-Install***')
    print(output)

def document_CloudWatch_ManageAgent_no_proxy(instanceEC2):
    """It launchs SSM Document to set no proxy in CW Agent in an EC2 instance
    
    Parameters
    ----------
    instanceEC2 : str
        Parameter Instance Id of an EC2 Instance

    Returns
    -------
    None
        Print a message and the response to the executed process
    """
    ssm = boto3.client('ssm')
    response = ssm.send_command(
        InstanceIds = [instanceEC2],
        DocumentName='Ib-CloudWatch-ManageAgent-no-proxy',
        CloudWatchOutputConfig={
            'CloudWatchLogGroupName': 'aws-systemsmanager/maintenance-cloudwatch-agent',
            'CloudWatchOutputEnabled': True
         }
        )
    command_id = response["Command"]["CommandId"]
    time.sleep(5)
    output = ssm.get_command_invocation(
            CommandId=command_id,
            InstanceId=instanceEC2
            )
    print('***Ib-CloudWatch-ManageAgent-no-proxy***')
    print(output)
    
def document_cloudWatch_agent_configure_metrics_logs_jboss_apps(instanceEC2, document_name, ssm_param, numexec):
    """It launchs the SSM Document to add more configurations to CW Agent in an EC2 instance
    
    Parameters
    ----------
    instanceEC2 : str
        Parameter Instance Id of an EC2 Instance
    document_name : str
        Name of the document that it will be launched
    ssm_param: str
        Name of the System Manager Parameter that it will be used to configurate CWA gent.   
    numexec: int
        Kind of configuration that must be applied to CWAgent. If equals: 1 'configure', rest 'configure (append)'
    Returns
    -------
    None
        Print a message and the response to the executed process
    """
    ssm = boto3.client('ssm')
    paramConfigure =""
    if (numexec==1):
        paramConfigure='configure'
    else:
        paramConfigure='configure (append)'
    response = ssm.send_command(
        InstanceIds = [instanceEC2],
        DocumentName=document_name,
        Parameters={'action':[paramConfigure],'mode':['ec2'],'optionalConfigurationSource':['ssm'],'optionalConfigurationLocation':[ssm_param],'optionalRestart':['yes']},
        CloudWatchOutputConfig={
            'CloudWatchLogGroupName': 'aws-systemsmanager/maintenance-cloudwatch-agent',
            'CloudWatchOutputEnabled': True
         }
        )
    command_id = response["Command"]["CommandId"]
    time.sleep(5)
    output = ssm.get_command_invocation(
            CommandId=command_id,
            InstanceId=instanceEC2
            )
    print('***'+document_name+'***')
    print(output)
              
              
def exist_Tag_in_EC2(instanceEC2,nameTag):
  """It validates if the tag exists in the EC2 instance
    
  Parameters
  ----------
  instanceEC2 : str
      Parameter Instance Id of an EC2 Instance
  nameTag: str
      Name of the tag that the process will check if exists or not    

  Returns
  -------
  bool
      True if tag exists, False if tag not exists
  """  
  clientEC2 = boto3.client('ec2')

  if (nameTag=='validateEC2Instance'):
      responseEC2_dt = clientEC2.describe_tags(Filters=[{'Name': "resource-id",'Values': [instanceEC2,],},],)
      if (len(responseEC2_dt['Tags']) == 0):
          message = 'EC2 instance '+instanceEC2+' does not exist in this account.'
          return {
                 'statusCode': 200,
                 'body': message      
          } 

  reservations = clientEC2.describe_instances(InstanceIds=[instanceEC2,],).get('Reservations', [])
  #print(reservations)
  for reservation in reservations:
    for instance in reservation['Instances']:
        tags = {}
        for tag in instance['Tags']:
            tags[tag['Key']] = tag['Value']

        if (nameTag=='ib:resource:apptype'):
          if not 'ib:resource:apptype' in tags:
            print (instance['InstanceId'] + " does not have ib:resource:apptype tag")
            return False
          else:
            if (tags['ib:resource:apptype']=='ews'):
              print (instance['InstanceId'] + " has tag ib:resource:apptype with value ews")
              return True
            elif (tags['ib:resource:apptype']=='eap'):
              print (instance['InstanceId'] + " has tag ib:resource:apptype with value eap")
              return True
            else:
              print (instance['InstanceId'] + " has tag ib:resource:apptype with value distinct than ews")    
              return False
              
        elif (nameTag=='ib:resource:monitoring'):
          if not 'ib:resource:monitoring' in tags:
            print (instance['InstanceId'] + " does not have ib:resource:monitoring tag")
            return False
          else:
            if (tags['ib:resource:monitoring']=='true'):
              print (instance['InstanceId'] + " has tag ib:resource:monitoring with value true")
              return True
            else:
              print (instance['InstanceId'] + " has tag ib:resource:monitoring with value distinct than true")    
              return False

        elif (nameTag=='ib:resource:environment'):
          if not 'ib:resource:environment' in tags:
            print (instance['InstanceId'] + " does not have ib:resource:environment tag")
            return False
          else:
              print (instance['InstanceId'] + " has tag ib:resource:environment")
              return True

        elif (nameTag=='validate_groupcomponentgrouping_o_ibresourceapplication'):
          if 'group:component-grouping' in tags:
              print (instance['InstanceId'] + " has tag group:component-grouping")
              if 'ib:resource:application' in tags:
                print (instance['InstanceId'] + " has tag ib:resource:application")
              else:  
                print (instance['InstanceId'] + " has no tag ib:resource:application")

              return True  
          else:
              print (instance['InstanceId'] + " has no tag group:component-grouping")
              if 'ib:resource:application' in tags:
                print (instance['InstanceId'] + " has tag ib:resource:application")
                return True  
                
              else:
                print (instance['InstanceId'] + " has no tag ib:resource:application")
                return False  

        elif (nameTag=='ib:account:name'):
          if not 'ib:account:name' in tags:
            print (instance['InstanceId'] + " does not have ib:account:name tag")
            return False
          else:
              print (instance['InstanceId'] + " has tag ib:account:name")
              return True
              
        elif (nameTag=='ib:resource:letter-ev'):
          if not 'ib:resource:letter-ev' in tags:
            print (instance['InstanceId'] + " does not have ib:resource:letter-ev tag")
            return False
          else:
              print (instance['InstanceId'] + " has tag ib:resource:letter-ev")
              return True