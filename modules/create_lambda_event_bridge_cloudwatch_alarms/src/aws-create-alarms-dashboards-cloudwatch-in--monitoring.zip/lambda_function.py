import json
import boto3
import time
import csv
import sys
import shutil
import os
from create_alarms_cw import ec2_default_cpuutilization
from create_alarms_cw import ec2_linux_disk_used_percent,ec2_linux_mem_used_percent
from create_alarms_cw import ec2_windows_logicaldisk_percent_free_space, ec2_windows_memory_available_bytes
from create_alarms_cw import ec2_custom_java_heap_mem_used_percent_datasource_status
from create_alarms_cw_phase_II import ec2_linux_cpu_usage_active, ec2_linux_cpu_usage_idle
from create_alarms_cw_phase_II import ec2_linux_cpu_usage_iowait, ec2_linux_cpu_usage_system
from create_alarms_cw_phase_II import ec2_linux_cpu_usage_user, ec2_linux_swap_used_percent
from create_alarms_cw_phase_II import ec2_linux_disk_inodes_free, ec2_linux_processes_idle
from create_alarms_cw_phase_II import ec2_linux_net_err_in, ec2_linux_net_err_out
from create_dashboard_cw import create_dashboard_cw
from aux_functions import aux_functions, ec2_delete_alarms, list_sns_topics

def lambda_handler(event, context):
    
    print(event)
    state = event['state']
    instanceEC2 = event['instanceEC2']
    account = event['account']
   
    if (state not in ["running","terminated"]):
        message='State: '+state+' is not admited'
        print(message)
        return {
                 'statusCode': 200,
                 'body': message      
        }

    if (instanceEC2==''):
        message='Invalid Instance Id'
        print(message)
        return {
                 'statusCode': 200,
                 'body': message      
        } 

    if (account==''):
        message='Invalid Account number'
        print(message)
        return {
                 'statusCode': 200,
                 'body': message      
        } 
            
    if(state=='running'):


        dict_values = aux_functions.getTagsFromInstance(instanceEC2)
        if('statusCode' in dict_values):
            return dict_values

        dict_values['account'] = account
        


        dictSNSTopic = list_sns_topics.getArnSNSTopic_from_monitoring(dict_values)
        if(dictSNSTopic['existsSNSTopic']==True):
            arnSNSTopic=dictSNSTopic['SnsTopicArn']
            print('SNS Topic Arn:'+arnSNSTopic)
        else:
            print(dictSNSTopic['SnsTopicArn'])
            return {
                 'statusCode': 200,
                 'body': dictSNSTopic['SnsTopicArn']      
            }


        validateTagGroupOrApplication = aux_functions.exist_Tag_in_EC2(instanceEC2,'validate_groupcomponentgrouping_o_ibresourceapplication')
        validateTagIbResourceEnvironment = aux_functions.exist_Tag_in_EC2(instanceEC2,'ib:resource:environment')
        validateTagMonitoring = aux_functions.exist_Tag_in_EC2(instanceEC2,'ib:resource:monitoring')
        validateTagIbAccountName = aux_functions.exist_Tag_in_EC2(instanceEC2,'ib:account:name')
        validateTagIbResourceLetterEv = aux_functions.exist_Tag_in_EC2(instanceEC2,'ib:resource:letter-ev')
        if (validateTagMonitoring and validateTagGroupOrApplication and validateTagIbResourceEnvironment and validateTagIbAccountName and validateTagIbResourceLetterEv):
            #This value should be 330 seconds (5 minutes and 30 seconds) to allow CloudWatch Agent to send metrics to CloudWatch
            # seconds = 330
            seconds = 330 
            m, s = divmod(seconds, 60)
            print("####################")
            print("We wait "+str(m)+" minutes and "+str(s)+ " seconds to create alarms. By default should be 5 minutes and 30 seconds.")
            print("####################")    
            time.sleep(seconds)

            # Create csv files to create ec2 alarms
            aux_functions.listMetrics_from_Cloudwatch_in_AccountResources(dict_values)

            # Phase I alarms 
            ec2_default_cpuutilization.create_alarm(dict_values,arnSNSTopic)
            ec2_linux_disk_used_percent.create_alarm(dict_values,arnSNSTopic)
            ec2_linux_mem_used_percent.create_alarm(dict_values,arnSNSTopic)
            ec2_windows_logicaldisk_percent_free_space.create_alarm(dict_values,arnSNSTopic)
            ec2_windows_memory_available_bytes.create_alarm(dict_values,arnSNSTopic)
            ec2_custom_java_heap_mem_used_percent_datasource_status.create_alarm_heap_mem_used_percent(dict_values,arnSNSTopic)
            ec2_custom_java_heap_mem_used_percent_datasource_status.create_alarm_datasource_status(dict_values,arnSNSTopic)
            
            # Phase II alarms 
            ec2_linux_cpu_usage_active.create_alarm(dict_values,arnSNSTopic)
            ec2_linux_cpu_usage_idle.create_alarm(dict_values,arnSNSTopic)
            ec2_linux_cpu_usage_iowait.create_alarm(dict_values,arnSNSTopic)
            ec2_linux_cpu_usage_system.create_alarm(dict_values,arnSNSTopic)
            ec2_linux_cpu_usage_user.create_alarm(dict_values,arnSNSTopic)
            ec2_linux_swap_used_percent.create_alarm(dict_values,arnSNSTopic)
            ec2_linux_disk_inodes_free.create_alarm(dict_values,arnSNSTopic)
            ec2_linux_processes_idle.create_alarm(dict_values,arnSNSTopic)
            ec2_linux_net_err_in.create_alarm(dict_values,arnSNSTopic)
            ec2_linux_net_err_out.create_alarm(dict_values,arnSNSTopic)
        else:
           message='ERROR: Instance: '+instanceEC2+" does not have one of these tags defined: ib:resource:monitoring, ib:resource:environment or one between group:component-grouping or ib:resource:application"
           print(message)
           return {
                 'statusCode': 200,
                 'body': message      
           }
    else: # state=='terminate'
      dict_values = aux_functions.getTagsFromInstance(instanceEC2)
      if('statusCode' in dict_values):
            return dict_values

      dict_values['account'] = account
      
      print('Delete CloudWatch Alarms')
      print("####################")
      ec2_delete_alarms.delete_cw_alarms(dict_values)
      
    create_dashboard_cw.create_dashboard(dict_values)
 
    
    return {
        'statusCode': 200,
        'body': json.dumps('Function executed correctly')
    }

      
    
