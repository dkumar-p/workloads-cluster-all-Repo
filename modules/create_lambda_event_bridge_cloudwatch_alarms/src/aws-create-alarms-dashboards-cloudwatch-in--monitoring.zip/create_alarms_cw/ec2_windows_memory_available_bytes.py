import json
import boto3
import time
import csv
import sys
import shutil
import os
from aux_functions import create_connection_with_monitoring_account

def create_alarm(dict_values,arnSNSTopic):
    """It creates CloudWatch alarms Memory Available Bytes from the EC2 instance of the dict and the csv created for this metric in function: aux_functions.listMetrics_from_Cloudwatch_in_AccountResources
    
    Parameters
    ----------
    dict_values : str
        Dictionary with the values that it will be used to delete cloudwatch alarms
    arnSNSTopic : str
        String with the arn of the SNS Topic where the alarms will send the notification when it passed to Alarm state
    
    Returns
    -------
    None
        Create the alarm and print a message
    """
    nombreMetrica='Memory Available Bytes'
    cluster=dict_values['cluster']
    entorno=dict_values['entorno']
    name=dict_values['name']
    apps=dict_values['apps']
    account=dict_values['account']
    existsTag_GroupComponentGrouping=dict_values['existsTag_GroupComponentGrouping']
    instanceEC2 = dict_values['instanceEC2']
    accountName  = dict_values['accountName']
    
    myListOfDictsOfTags = dict_values['myListOfDictsOfTags']
    tagAuxName = 'CloudWatch_Alarm_CWAgent_'+nombreMetrica.replace(" ","_")
    dictName = {'Key': 'Name', 'Value': tagAuxName }
    myListOfDictsOfTags.append(dictName)
    dictIbResourceName = {'Key': 'ib:resource:name', 'Value': tagAuxName}
    myListOfDictsOfTags.append(dictIbResourceName)

    monitoringCloudwatchClient = create_connection_with_monitoring_account.function_asume_role_from_monitoring_account('cloudwatch')
    
    nombreFichero='/tmp/cw_ec2_metrics_csv_files_'+instanceEC2+'/'+instanceEC2+'_'+nombreMetrica.replace(" ","_")+'.csv'
    with open(nombreFichero, newline='') as csvfile:
       reader = csv.DictReader(csvfile) 
       row_count = sum(1 for row in reader)
       print('Alarmas '+nombreMetrica+' de la instancia '+instanceEC2+' que se van a crear: '+str(row_count))

    if row_count > 0:
      with open(nombreFichero, newline='') as csvfile:
        reader = csv.DictReader(csvfile)             
        for row in reader:
            if (existsTag_GroupComponentGrouping==False): # This instance doesn't belong to an ASG 
                app_or_cluster=apps
                app_or_cluster_description=" de la aplicación "+apps

            else:
                app_or_cluster=cluster
                app_or_cluster_description=" del cluster "+cluster+" formado por las aplicaciones "+apps

            if 'AutoScalingGroupName' not in row:
                Dimensions_list= [
                           { 'Name': 'InstanceId','Value': row['InstanceId']},
                           { 'Name': 'InstanceType','Value': row['InstanceType']},
                        ]
            else:
                Dimensions_list= [
                           { 'Name': 'AutoScalingGroupName','Value': row['AutoScalingGroupName']},
                           { 'Name': 'InstanceId','Value': row['InstanceId']},
                           { 'Name': 'InstanceType','Value': row['InstanceType']},
                        ]
                        
            #bytes to megabytes: https://www.calculateme.com/computer-storage/megabytes/to-bytes/256
            mythreshold=256000000
            mytresholdinmegabytes=mythreshold/1000000
            Alarm_Name = "IBERIA-AWS-ALERTAS/"+account+"/ec2/memory_available_bytes/"+app_or_cluster+"/"+entorno+"/"+name+"/"+instanceEC2
            Alarm_Desc = "Parámetro Memory Available Bytes de la máquina "+name+"("+instanceEC2+")"+app_or_cluster_description+" en la cuenta de "+accountName+" ("+account+") se encuentra por debajo de "+str(mytresholdinmegabytes)+" MBytes. Abrir ticket a grupo INFRASUP_INTEL_WIN"          

            monitoringCloudwatchClient.put_metric_alarm(
              AlarmName=Alarm_Name,
              AlarmDescription=Alarm_Desc,
              ComparisonOperator='LessThanThreshold',
              EvaluationPeriods=2,
              Threshold=mythreshold,
              AlarmActions=[arnSNSTopic,],
              Metrics=[
               {
                 'Id': 'm1',
                 'AccountId': account,
                 'ReturnData': True,
                 'MetricStat': {
                      'Metric': {
                         'Namespace': 'CWAgent',
                         'MetricName': nombreMetrica,
                         'Dimensions': Dimensions_list, 
                      },
                      'Period': 300,
                      'Stat': 'Average',
                    },
                 },
              ],
              Tags = myListOfDictsOfTags,
            )
    print('***************')        