from aux_functions import create_connection_with_monitoring_account

def delete_cw_alarms(dict_values):
    """It deletes all the CloudWatch alarms from the EC2 instance of the dict
    
    Parameters
    ----------
    dict_values : str
        Dictionary with the values that it will be used to delete cloudwatch alarms

    
    Returns
    -------
    None
        Print a message
    """
    cluster=dict_values['cluster']
    entorno=dict_values['entorno']
    name=dict_values['name']
    apps=dict_values['apps']
    account=dict_values['account']
    existsTag_GroupComponentGrouping=dict_values['existsTag_GroupComponentGrouping']
    instanceEC2 = dict_values['instanceEC2']
    
    if (existsTag_GroupComponentGrouping==False): 
        cluster_or_app_name = apps

    else: 
        cluster_or_app_name = cluster
 
    
    delete_alarm('CPUUtilization',cluster_or_app_name,entorno,name,instanceEC2,account)
    delete_alarm('disk_used_percent',cluster_or_app_name,entorno,name,instanceEC2,account)
    delete_alarm('mem_used_percent',cluster_or_app_name,entorno,name,instanceEC2,account)
    delete_alarm('logicaldisk_percent_free_space',cluster_or_app_name,entorno,name,instanceEC2,account)
    delete_alarm('memory_available_bytes',cluster_or_app_name,entorno,name,instanceEC2,account)
    delete_alarm('heap_mem_used_percent',cluster_or_app_name,entorno,name,instanceEC2,account)
    delete_alarm('datasource',cluster_or_app_name,entorno,name,instanceEC2,account)

    delete_alarm('cpu_usage_active',cluster_or_app_name,entorno,name,instanceEC2,account)
    delete_alarm('cpu_usage_idle',cluster_or_app_name,entorno,name,instanceEC2,account)
    delete_alarm('cpu_usage_iowait',cluster_or_app_name,entorno,name,instanceEC2,account)
    delete_alarm('cpu_usage_system',cluster_or_app_name,entorno,name,instanceEC2,account)
    delete_alarm('cpu_usage_user',cluster_or_app_name,entorno,name,instanceEC2,account)
    delete_alarm('disk_inodes_free',cluster_or_app_name,entorno,name,instanceEC2,account)
    delete_alarm('net_err_in',cluster_or_app_name,entorno,name,instanceEC2,account)
    delete_alarm('net_err_out',cluster_or_app_name,entorno,name,instanceEC2,account)
    delete_alarm('processes_idle',cluster_or_app_name,entorno,name,instanceEC2,account)
    delete_alarm('swap_used_percent',cluster_or_app_name,entorno,name,instanceEC2,account)
    print('***************')        

def delete_alarm(metric_name,cluster_or_app_name,entorno,name,instanceEC2,account):
    """It deletes the CloudWatch alarm that matches with the name results at the concatenation with the values of these parameters
    
    Parameters
    ----------
    metric_name : str
        Name of the metric that it will be removed
    cluster_or_app_name: str
        Parameter that include the name of the cluster oor the name of the application that it's included in the alarm that it will be removed
    entorno: str
        Environment of the alarm that it will be removed
    name: str
        Name of the EC2 instance of the alarm that it will be removed
    instanceEC2: str
        Instance Id of the EC2 instance of the alarm that it will be removed
    account: str
        Number of the account of the EC2 instance of the alarms that it will be removed
    
    Returns
    -------
    None
        Print a message when the alarm has been removed or if it does not exist
    """
    monitoringCloudwatchClient = create_connection_with_monitoring_account.function_asume_role_from_monitoring_account('cloudwatch')
    alarm_name_prefix='IBERIA-AWS-ALERTAS/'+account+'/ec2/'+metric_name+'/'+cluster_or_app_name+'/'+entorno+'/'+name+'/'+instanceEC2
    responseDescribe_Alarm = monitoringCloudwatchClient.describe_alarms(AlarmNamePrefix=alarm_name_prefix,)
    if(len(responseDescribe_Alarm['MetricAlarms'])>0):
        for alarm in responseDescribe_Alarm['MetricAlarms']:
            respDelete=monitoringCloudwatchClient.delete_alarms(AlarmNames=[alarm['AlarmName'],])
            print('This alarm has been removed: '+alarm['AlarmName'])
    else:
        print('This alarm does not exist: '+alarm_name_prefix)
