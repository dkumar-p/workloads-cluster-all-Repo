import json
import boto3
import time
import csv
import sys
import shutil
import os


def getTagsFromInstance(instanceEC2):
    """It creates a dict with some tags from the instance
    
    Parameters
    ----------
    instanceEC2 : str
        Parameter Instance Id of an EC2 Instance

    
    Returns
    -------
    dict
        Dictionary with key/values from the EC2 instance that will be used to create alarms and the dashboard
    """  
    clientEC2 = boto3.client('ec2')
    cluster=""
    entorno=""
    name=""
    apps=""
    letterev=""
    responseEC2_dt = clientEC2.describe_tags(Filters=[{'Name': "resource-id",'Values': [instanceEC2,],},],)
    if (len(responseEC2_dt['Tags']) == 0):
      message = 'EC2 instance '+instanceEC2+' does not exist in this account.'
      return {
                 'statusCode': 200,
                 'body': message      
      } 
    
    existsTag_GroupComponentGrouping=False
    myListOfDictsOfTags = createListOfDictsOfTags(responseEC2_dt['Tags'])
    for ec2tag in responseEC2_dt['Tags']:
        if (ec2tag['Key']=="group:component-grouping"):
          cluster=ec2tag['Value']
          existsTag_GroupComponentGrouping=True
        elif (ec2tag['Key']=="ib:resource:environment"):
          entorno=ec2tag['Value']
        elif (ec2tag['Key']=="Name"):
          name=ec2tag['Value']        
        elif (ec2tag['Key']=="ib:resource:application"):
          apps=ec2tag['Value']     
        elif (ec2tag['Key']=="ib:resource:letter-ev"):
          letterev=ec2tag['Value']
        elif (ec2tag['Key']=="ib:account:name"):
          accountName=ec2tag['Value']    
    results = {
        'existsTag_GroupComponentGrouping': existsTag_GroupComponentGrouping,
        'cluster': cluster,
        'entorno' : entorno,
        'name' : name,
        'apps' : apps,
        'instanceEC2' : instanceEC2,
        'letterev' : letterev,
        'myListOfDictsOfTags': myListOfDictsOfTags,
        'accountName': accountName
    }
    return results

def getCustomFilter(dict_values):
    """It creates the list of dictionary which will be use to filter AWS resources
    
    Parameters
    ----------
    dict_values : dict
        Dictionary with the values that it will be used to create the filter


    Returns
    -------
    list
        List of dicts that it will be used to filter AWS resources
    """  
    cluster=dict_values['cluster']
    apps=dict_values['apps']
    account=dict_values['account']
    entorno=dict_values['entorno']
    existsTag_GroupComponentGrouping=dict_values['existsTag_GroupComponentGrouping']
    instanceEC2 = dict_values['instanceEC2']
    
    #clientEC2 = boto3.client('ec2')
    if (existsTag_GroupComponentGrouping):
        custom_filter = [
            {
                'Name':'tag:group:component-grouping', 
                'Values': [cluster]},
            {
                'Name':'tag:ib:resource:environment', 
                'Values': [entorno]
            }
        ]
    else:
        custom_filter = [
            {
                'Name':'tag:ib:resource:application', 
                'Values': [apps]},
            {
                'Name':'tag:ib:resource:environment', 
                'Values': [entorno]
            }
        ]
    return custom_filter
    
    
def add_quote(a):
  """It adds double quotes at the begining and at the end of the string
    
  Parameters
  ----------
  a : str
      String that will be edited with double quotes in its first and last position 


  Returns
  -------
  str
      String with double quotes in its first and last position
  """  
  return '"{0}"'.format(a)
    
    

    
def listMetrics_from_Cloudwatch_in_AccountResources(dict_values):   
    """It creates a csv file for each CW Metrics defined in listaNameSpace_Metrica of the EC2 instance Id from the dict dict_values
    
    Parameters
    ----------
    dict_value : dict
        Dict with values of tags from an EC2 instance

    
    Returns
    -------
    None
        It creates a CSV file with the dimensions for each CW Metrics define in listaNameSpace_Metric of the EC2 instance Id from the dict dict_values. 
        It an EC2 instance hasn't data from a metric the csv file will have a header line with value 'FicheroVacio'
    """    
    clientEC2 = boto3.client('ec2')
    cluster=dict_values['cluster']
    entorno=dict_values['entorno']
    name=dict_values['name']
    apps=dict_values['apps']
    account=dict_values['account']
    existsTag_GroupComponentGrouping=dict_values['existsTag_GroupComponentGrouping']
    #print(existsTag_GroupComponentGrouping)
    instanceEC2 = dict_values['instanceEC2']
    
    # define the name of the directory to be created
    path = "/tmp/cw_ec2_metrics_csv_files_"+instanceEC2
    
    # define the access rights
    access_rights = 0o755
    
    isExist = os.path.exists(path)
    if (isExist):
        shutil.rmtree(path)   
    try:
        os.mkdir(path, access_rights)
    except OSError:
        print ("Creation of the directory %s failed" % path)
    else:
        print ("Successfully created the directory %s" % path)
        
        
    #responseEC2 = clientEC2.describe_instances(Filters=custom_filter)

    #print(responseEC2)
    listaEC2 = []

    listaEC2.append(instanceEC2)

          
    clientAccountResources = boto3.client('cloudwatch')

    # listaNameSpace_Metric should be equal than defined in aux_functions/list_all_ec2.py in function: getListEC2InstancesRunning_For_CloudWatch_Widgets
    listaNameSpace_Metrica = [['CWAgent','Memory Available Bytes'],['CWAgent','LogicalDisk % Free Space'],['CWAgent','mem_used_percent'],['CWAgent','disk_used_percent'],['AWS/EC2','CPUUtilization'],['Custom','datasource_status'], ['Custom','heap_mem_used_percent'], ['CWAgent','cpu_usage_idle'], ['CWAgent','cpu_usage_iowait'], ['CWAgent','cpu_usage_system'], ['CWAgent','cpu_usage_user'], ['CWAgent','cpu_usage_active'], ['CWAgent','disk_inodes_free'], ['CWAgent','net_err_in'], ['CWAgent','net_err_out'], ['CWAgent','processes_idle'], ['CWAgent','swap_used_percent'] ]

    
    for item in listaNameSpace_Metrica:
      iteracion=0
      listaCompleta=[]
      listaCabecera=[]  
      for idec2 in listaEC2:
         responseAccountResources = clientAccountResources.list_metrics(
                Namespace=item[0],
                MetricName=item[1],
                Dimensions=[{'Name': 'InstanceId', 'Value': idec2}]
            )
         for each_metric in responseAccountResources['Metrics']:


                    if("AutoScalingGroupName" in [x['Name'] for x in each_metric['Dimensions']]): # Its a instance in an ASG
                      if (item[1]=='disk_used_percent'):
                        if (len(each_metric['Dimensions'])!=6):                 
                          continue
                      if (item[1]=='mem_used_percent'):   
                        if (len(each_metric['Dimensions'])!=3):                 
                          continue 
                      if (item[1]=='Memory Available Bytes'):    
                        if (len(each_metric['Dimensions'])!=3):
                         continue             
                      if (item[1]=='LogicalDisk % Free Space'):
                        if (len(each_metric['Dimensions'])!=5):
                          continue  
                    else:     
                      if (item[1]=='disk_used_percent'):
                        if (len(each_metric['Dimensions'])!=5):                 
                          continue
                      if (item[1]=='mem_used_percent'):   
                        if (len(each_metric['Dimensions'])!=2):                 
                          continue 
                      if (item[1]=='Memory Available Bytes'):    
                        if (len(each_metric['Dimensions'])!=2):
                         continue             
                      if (item[1]=='LogicalDisk % Free Space'):
                        if (len(each_metric['Dimensions'])!=4):
                          continue  
                    """    
                    if (existsTag_GroupComponentGrouping==False): #False
                      if (item[1]=='disk_used_percent'):
                        if (len(each_metric['Dimensions'])!=5):                 
                          continue
                      if (item[1]=='mem_used_percent'):   
                        if (len(each_metric['Dimensions'])!=2):                 
                          continue 
                      if (item[1]=='Memory Available Bytes'):    
                        if (len(each_metric['Dimensions'])!=2):
                         continue             
                      if (item[1]=='LogicalDisk % Free Space'):
                        if (len(each_metric['Dimensions'])!=4):
                          continue  
                    else:  # Its a instance in an ASG
                      if (item[1]=='disk_used_percent'):
                        if (len(each_metric['Dimensions'])!=6):                 
                          continue
                      if (item[1]=='mem_used_percent'):   
                        if (len(each_metric['Dimensions'])!=3):                 
                          continue 
                      if (item[1]=='Memory Available Bytes'):    
                        if (len(each_metric['Dimensions'])!=3):
                         continue             
                      if (item[1]=='LogicalDisk % Free Space'):
                        if (len(each_metric['Dimensions'])!=5):
                          continue  
                    """
                    listaElementos = []
                    listaCabecera = []
                  
                      #print(each_metric['Dimensions'])
                    for each_dimensions in each_metric['Dimensions']:
                            
                        listaElementos.append(each_dimensions['Value'])
                        listaCabecera.append(each_dimensions['Name'])
                    listaCompleta.append(listaElementos)
                    #print(listaCabecera)    
                     #listaCompleta.append(cabecera)
                     #listaCompleta.append(resto)    
    
                     #print(resto)   
       
      if (len(listaCabecera)==0):
           listaCabecera.append('FicheroVacio')          
    
      listaCompleta.insert(0,listaCabecera) 
    
      nombreMetrica = item[1].replace(" ","_")
      nombreFichero = instanceEC2+'_'+nombreMetrica+'.csv'
      directorio='/tmp/cw_ec2_metrics_csv_files_'+instanceEC2+'/'

           
      with open(directorio+nombreFichero, 'a+', newline ='') as f:
             write = csv.writer(f)
             write.writerows(listaCompleta)    
      #print("Fichero "+directorio+nombreFichero+" generado correctamente")  
    print("####################")
      



def createListOfDictsOfTags(listsOfTags):
  """It creates a list of dicts of tags from othe list of dicts of tags that will be used to create Tags for CloudWatch Alarms
    
  Parameters
  ----------
  listsOfTags : list
      List of dict of tags that will be transformed
   

  Returns
  -------
  list
      List of dicts with tags key and value that will be used to create Tags for CloudWatch Alarms
      If the list of dicts contains both group:component-grouping and ib:resource:application, 
      ib:resource:application dict will be removed from the final list
  """ 
  existsTag_GroupComponentGrouping=False
  myListOfDictsOfTags = []
  for ec2tag in listsOfTags:
        myDictOfTags = {}
        if (ec2tag['Key']=="company"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="delete_after"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="environment"):
          myDictOfTags['Key']=ec2tag['Key']   
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="typeproject"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="owner"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="project"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="sponsor"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="ib:resource:op-co-code"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="group:component-grouping"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          existsTag_GroupComponentGrouping=True

        elif (ec2tag['Key']=="ib:resource:application"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="ib:resource:environment"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="ib:account:environment"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="ib:account:short_name"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="ib:account:name"):
          myDictOfTags['Key']=ec2tag['Key'] 
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="ib:resource:business-domain"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="ib:resource:business-service"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="ib:account:service-offering"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          
        elif (ec2tag['Key']=="ib:resource:letter-ev"):
          myDictOfTags['Key']=ec2tag['Key']
          myDictOfTags['Value']=ec2tag['Value']
          
        if len(myDictOfTags) != 0: 
           myListOfDictsOfTags.append(myDictOfTags)
  listResult = []         
  if (existsTag_GroupComponentGrouping==True):
    listResult = [i for i in myListOfDictsOfTags if not (i['Key'] == 'ib:resource:application')]
  else:
    listResult = myListOfDictsOfTags
  return listResult

def exist_Tag_in_EC2(instanceEC2,nameTag):
  """It validates if the tag exists in the EC2 instance
    
  Parameters
  ----------
  instanceEC2 : str
      Parameter Instance Id of an EC2 Instance
  nameTag: str
      Name of the tag that the process will check if exists or not    

  Returns
  -------
  bool
      True if tag exists, False if tag not exists
  """  
  clientEC2 = boto3.client('ec2')
  reservations = clientEC2.describe_instances(InstanceIds=[instanceEC2,],).get('Reservations', [])
  #print(reservations)
  for reservation in reservations:
    for instance in reservation['Instances']:
        tags = {}
        for tag in instance['Tags']:
            tags[tag['Key']] = tag['Value']

        if (nameTag=='ib:resource:apptype'):
          if not 'ib:resource:apptype' in tags:
            print (instance['InstanceId'] + " does not have ib:resource:apptype tag")
            return False
          else:
            if (tags['ib:resource:apptype']=='ews'):
              print (instance['InstanceId'] + " has tag ib:resource:apptype with value ews")
              return True
            elif (tags['ib:resource:apptype']=='eap'):
              print (instance['InstanceId'] + " has tag ib:resource:apptype with value eap")
              return True
            else:
              print (instance['InstanceId'] + " has tag ib:resource:apptype with value distinct than ews")    
              return False
              
        elif (nameTag=='ib:resource:monitoring'):
          if not 'ib:resource:monitoring' in tags:
            print (instance['InstanceId'] + " does not have ib:resource:monitoring tag")
            return False
          else:
            if (tags['ib:resource:monitoring']=='true'):
              print (instance['InstanceId'] + " has tag ib:resource:monitoring with value true")
              return True
            else:
              print (instance['InstanceId'] + " has tag ib:resource:monitoring with value distinct than true")    
              return False

        elif (nameTag=='ib:resource:environment'):
          if not 'ib:resource:environment' in tags:
            print (instance['InstanceId'] + " does not have ib:resource:environment tag")
            return False
          else:
              print (instance['InstanceId'] + " has tag ib:resource:environment")
              return True

        elif (nameTag=='validate_groupcomponentgrouping_o_ibresourceapplication'):
          if 'group:component-grouping' in tags:
              print (instance['InstanceId'] + " has tag group:component-grouping")
              if 'ib:resource:application' in tags:
                print (instance['InstanceId'] + " has tag ib:resource:application")
              else:  
                print (instance['InstanceId'] + " has no tag ib:resource:application")

              return True  
          else:
              print (instance['InstanceId'] + " has no tag group:component-grouping")
              if 'ib:resource:application' in tags:
                print (instance['InstanceId'] + " has tag ib:resource:application")
                return True  
                
              else:
                print (instance['InstanceId'] + " has no tag ib:resource:application")
                return False  

        elif (nameTag=='ib:account:name'):
          if not 'ib:account:name' in tags:
            print (instance['InstanceId'] + " does not have ib:account:name tag")
            return False
          else:
              print (instance['InstanceId'] + " has tag ib:account:name")
              return True
              
        elif (nameTag=='ib:resource:letter-ev'):
          if not 'ib:resource:letter-ev' in tags:
            print (instance['InstanceId'] + " does not have ib:resource:letter-ev tag")
            return False
          else:
              print (instance['InstanceId'] + " has tag ib:resource:letter-ev")
              return True