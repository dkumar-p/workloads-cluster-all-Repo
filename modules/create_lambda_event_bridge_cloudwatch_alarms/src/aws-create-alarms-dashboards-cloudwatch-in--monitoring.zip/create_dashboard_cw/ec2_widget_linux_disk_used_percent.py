import json
import boto3
import time
import csv
import sys
import shutil
import os
from aux_functions import aux_functions


def ec2_string_disk_used_percent(dict_values):
    """It creates CloudWatch widget string to CloudWatch Dashboard of CWAgent namespace metric: disk_used_percent. The data from the EC2 instances is obtained from csv created for this metric in function: list_all_ec2.getListEC2InstancesRunning_For_CloudWatch_Widgets
    
    Parameters
    ----------
    dict_values : str
        Dictionary with the values that it will be used to update cloudwatch dashboard
    
    Returns
    -------
    Str
        String with the widget of CWAgent namespace metric: disk_used_percent
    """
    nombreMetrica='disk_used_percent'
    cluster=dict_values['cluster']
    entorno=dict_values['entorno']
    name=dict_values['name']
    apps=dict_values['apps']
    account=dict_values['account']
    existsTag_GroupComponentGrouping=dict_values['existsTag_GroupComponentGrouping']
    instanceEC2 = dict_values['instanceEC2']
    
    nombreFichero='/tmp/cw_dashboard_ec2_metrics_csv_files/'+nombreMetrica.replace(" ","_")+'.csv'
    with open(nombreFichero, newline='') as csvfile:
       reader = csv.DictReader(csvfile) 
       row_count = sum(1 for row in reader)
       print('Widget Linux EC2 - Disk Used Percent % con '+str(row_count)+' discos')
       
       #for field in reader.fieldnames:
       #         print(field)
    if row_count > 0:
      i=0
      with open(nombreFichero, newline='') as csvfile:
        reader = csv.DictReader(csvfile)             
        
        cadenaCompleta=""
        for row in reader:
          
          i=i+1
          dict_values_instance = aux_functions.getTagsFromInstance(row['InstanceId'])
          cadena=""
          cadena=cadena+"""["CWAgent", "disk_used_percent" """ 
          cadena=cadena+""", "path", """+aux_functions.add_quote(row['path'])
          cadena=cadena+""", "InstanceId","""+aux_functions.add_quote(dict_values_instance['instanceEC2'])
          if 'AutoScalingGroupName' in row:
            cadena=cadena+""", "AutoScalingGroupName", """+aux_functions.add_quote(row['AutoScalingGroupName'])
          cadena=cadena+""", "InstanceType","""+aux_functions.add_quote(row['InstanceType'])  
          cadena=cadena+""", "device","""+aux_functions.add_quote(row['device'])
          cadena=cadena+""", "fstype","""+aux_functions.add_quote(row['fstype'])
          cadena=cadena+""", { "accountId" : """+aux_functions.add_quote(account)
          cadena=cadena+""", "label" : """
          cadena=cadena+aux_functions.add_quote("("+row['path']+") "+dict_values_instance['name']+" ("+dict_values_instance['instanceEC2']+")")
          if (i<row_count):
            cadena=cadena+"}],"""
          else:  
            cadena=cadena+"}]"""
          cadenaCompleta=cadenaCompleta+cadena
        #print(cadenaCompleta)
    
      stringWidgetDiskUsedPercent ="""{
            "height": 6,
            "width": 12,
            "x": 0,
            "y": 6,
            "type": "metric",
            "properties": {
                "metrics": ["""
      stringWidgetDiskUsedPercent =stringWidgetDiskUsedPercent+cadenaCompleta
      stringWidgetDiskUsedPercent =stringWidgetDiskUsedPercent+"""],
                "region": "eu-west-1",
                "stacked": false,
                "title": "Linux EC2 - Disk Used Percent %",
                "view": "singleValue"
            }
        }"""     
        
    else:
      stringWidgetDiskUsedPercent=""
    #print(stringWidgetDiskUsedPercent)
    return(stringWidgetDiskUsedPercent)
    
    
