import json
import boto3
import time
import csv
import sys
import shutil
import os
from aux_functions import aux_functions, list_all_rds


def rds_string(dict_values):
    """It creates CloudWatch widget string to CloudWatch Dashboard of RDS metrics: CPUUtilization, FreeableMemory and FreeStorageSpace included in lista_metricas_rds. The data from RDS is obtained from functions: list_all_rds.getArnRDS and list_all_rds.getRDSName
    
    Parameters
    ----------
    dict_values : str
        Dictionary with the values that it will be used to update cloudwatch dashboard
    
    Returns
    -------
    Str
        String with the widget of RDS metrics: CPUUtilization, FreeableMemory and FreeStorageSpace included in lista_metricas_rds
    """
    lista_metricas_rds = ["CPUUtilization", "FreeableMemory", "FreeStorageSpace"]

    cluster=dict_values['cluster']
    entorno=dict_values['entorno']
    name=dict_values['name']
    apps=dict_values['apps']
    account=dict_values['account']
    existsTag_GroupComponentGrouping=dict_values['existsTag_GroupComponentGrouping']
    instanceEC2 = dict_values['instanceEC2']

    list_RDS_Arns = list_all_rds.getArnRDS(dict_values)
    list_RDS = list_all_rds.getRDSName(list_RDS_Arns)
    if (len(list_RDS)==0):
      cadCompl=""
      
    else:
      i=0
      cadCompl=""
      for rds_metric in lista_metricas_rds:
        i=i+1
        j=0
        cadenaCompleta=""
        print('Widget '+rds_metric+' - RDS con: '+str(len(list_RDS))+' instancias')
        for row in list_RDS:
          j=j+1
          cadena=""
          cadena=cadena+"""["AWS/RDS", """+aux_functions.add_quote(rds_metric)
          cadena=cadena+""", "DBInstanceIdentifier", """+aux_functions.add_quote(row)
          cadena=cadena+""", { "accountId" : """+aux_functions.add_quote(account)
          cadena=cadena+""", "label" : """
          cadena=cadena+aux_functions.add_quote(row)
          if (j<len(list_RDS)):
            cadena=cadena+"}],"""
          else:  
              cadena=cadena+"}]"""
          cadenaCompleta=cadenaCompleta+cadena
        stringWidgetRDS ="""{
					"height": 6,
					"width": 12,
					"x": 0,
					"y": 6,
					"type": "metric",
					"properties": {
						"metrics": ["""
        stringWidgetRDS =stringWidgetRDS+cadenaCompleta
        stringWidgetRDS =stringWidgetRDS+"""],
						"region": "eu-west-1",
						"stacked": false,
						"title": "RDS - """+rds_metric+""" ",
						"view": "timeSeries"
					}
				}"""
        if (i<len(lista_metricas_rds)):
          stringWidgetRDS=stringWidgetRDS+","
        cadCompl=cadCompl+stringWidgetRDS

    #print(cadCompl)
    return(cadCompl)