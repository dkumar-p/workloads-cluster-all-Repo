import json
import boto3
import time
import csv
import sys
import shutil
import os
from aux_functions import aux_functions, list_all_ec2
from aux_functions import create_connection_with_monitoring_account
from create_dashboard_cw import ec2_widget_default
from create_dashboard_cw import ec2_widget_linux_disk_used_percent, ec2_widget_linux_mem_used_percent
from create_dashboard_cw import ec2_widget_windows_logicaldisk_percent_free_space, ec2_widget_windows_memory_available_bytes
from create_dashboard_cw import ec2_widget_custom_java_heap_mem_used_percent_datasource_status
from create_dashboard_cw import alb_tg_widgets, rds_widgets
import re

def create_dashboard(dict_values):
    """It creates CloudWatch Dashboard in Monitoring Account, and concatenates the strings from widgets generated in all the functions that are called by this.
    
    Parameters
    ----------
    dict_values : str
        Dictionary with the values that it will be used to update cloudwatch dashboard
    
    Returns
    -------
    None
       Execute putDashBoard action in Monitoring Account
    """
    cluster=dict_values['cluster']
    entorno=dict_values['entorno']
    name=dict_values['name']
    apps=dict_values['apps']
    account=dict_values['account']
    existsTag_GroupComponentGrouping=dict_values['existsTag_GroupComponentGrouping']
    instanceEC2 = dict_values['instanceEC2']
    letterev = dict_values['letterev']
    

    monitoringCloudwatchClient = create_connection_with_monitoring_account.function_asume_role_from_monitoring_account('cloudwatch')

    if existsTag_GroupComponentGrouping:
        db_name=cluster
        custom_filter=aux_functions.getCustomFilter(dict_values)
    else:
        db_name=apps
        custom_filter=aux_functions.getCustomFilter(dict_values)
       
    db_name = re.sub('[^A-Za-z0-9-_]+', '_', db_name)
    nombreDashboard='c'+letterev+'ame2idcw'+"00001"+"_"+db_name+"_"+entorno+"_dashboard"
    print(nombreDashboard)

    # Create csv files to create ec2 widgets
    list_all_ec2.getListEC2InstancesRunning_For_CloudWatch_Widgets(custom_filter)

    # EC2 widgets
    ec2_string_cpuutilization=ec2_widget_default.ec2_string_cpuutilization(dict_values)
    
    ec2_string_network_in_out=ec2_widget_default.ec2_string_network_in_out(dict_values)
    if(ec2_string_network_in_out!=''):
        ec2_string_network_in_out=','+ec2_string_network_in_out
        
    ec2_string_network_packets_in_out=ec2_widget_default.ec2_string_network_packets_in_out(dict_values)
    if(ec2_string_network_packets_in_out!=''):
        ec2_string_network_packets_in_out=','+ec2_string_network_packets_in_out    
    
    ec2_string_statuscheckfailed = ec2_widget_default.ec2_string_statuscheckfailed(dict_values)
    if(ec2_string_statuscheckfailed!=''):
        ec2_string_statuscheckfailed=','+ec2_string_statuscheckfailed

    ec2_string_disk_used_percent = ec2_widget_linux_disk_used_percent.ec2_string_disk_used_percent(dict_values)
    if(ec2_string_disk_used_percent!=''):
        ec2_string_disk_used_percent=','+ec2_string_disk_used_percent
        
    ec2_string_mem_used_percent = ec2_widget_linux_mem_used_percent.ec2_string_mem_used_percent(dict_values)
    if(ec2_string_mem_used_percent!=''):
        ec2_string_mem_used_percent=','+ec2_string_mem_used_percent
    
    ec2_string_logicaldisk_percent_free_space = ec2_widget_windows_logicaldisk_percent_free_space.ec2_string_logicaldisk_percent_free_space(dict_values)
    if(ec2_string_logicaldisk_percent_free_space!=''):
        ec2_string_logicaldisk_percent_free_space=','+ec2_string_logicaldisk_percent_free_space
        
    ec2_string_memory_available_bytes = ec2_widget_windows_memory_available_bytes.ec2_string_memory_available_bytes(dict_values)
    if(ec2_string_memory_available_bytes!=''):
        ec2_string_memory_available_bytes=','+ec2_string_memory_available_bytes
        

    ec2_string_java_heap_mem_used_percent = ec2_widget_custom_java_heap_mem_used_percent_datasource_status.ec2_string_java_heap_mem_used_percent(dict_values)
    if(ec2_string_java_heap_mem_used_percent!=''):
        ec2_string_java_heap_mem_used_percent=','+ec2_string_java_heap_mem_used_percent
        
    ec2_string_java_datasource_status = ec2_widget_custom_java_heap_mem_used_percent_datasource_status.ec2_string_java_datasource_status(dict_values)
    if(ec2_string_java_datasource_status!=''):
        ec2_string_java_datasource_status=','+ec2_string_java_datasource_status
    
    # ALB and TG widgets
    alb_tg_string_TargetResponseTime = alb_tg_widgets.alb_tg_string_TargetResponseTime(dict_values)
    if(alb_tg_string_TargetResponseTime!=''):
        alb_tg_string_TargetResponseTime=','+alb_tg_string_TargetResponseTime
    
    alb_tg_string_UnHealthyHostCount = alb_tg_widgets.alb_tg_string_UnHealthyHostCount(dict_values)
    if(alb_tg_string_UnHealthyHostCount!=''):
        alb_tg_string_UnHealthyHostCount=','+alb_tg_string_UnHealthyHostCount  
        
    alb_tg_string_HTTPCode_Target_5XX_Count = alb_tg_widgets.alb_tg_string_HTTPCode_Target_5XX_Count(dict_values)   
    if(alb_tg_string_HTTPCode_Target_5XX_Count!=''):
        alb_tg_string_HTTPCode_Target_5XX_Count=','+alb_tg_string_HTTPCode_Target_5XX_Count  

    # RDS widgets    
    rds_string = rds_widgets.rds_string(dict_values)    
    if(rds_string!=''):
        rds_string=','+rds_string  
    
    json_db_body=''
    json_db_body=json_db_body+ec2_string_cpuutilization
    json_db_body=json_db_body+ec2_string_statuscheckfailed
    json_db_body=json_db_body+ec2_string_disk_used_percent
    json_db_body=json_db_body+ec2_string_mem_used_percent
    json_db_body=json_db_body+ec2_string_logicaldisk_percent_free_space
    json_db_body=json_db_body+ec2_string_memory_available_bytes
    json_db_body=json_db_body+ec2_string_java_heap_mem_used_percent
    json_db_body=json_db_body+ec2_string_java_datasource_status
    json_db_body=json_db_body+ec2_string_network_in_out
    json_db_body=json_db_body+ec2_string_network_packets_in_out
    json_db_body=json_db_body+alb_tg_string_TargetResponseTime
    json_db_body=json_db_body+alb_tg_string_UnHealthyHostCount
    json_db_body=json_db_body+rds_string
    json_db_body=json_db_body+alb_tg_string_HTTPCode_Target_5XX_Count
    if(len(json_db_body)>0):
     if(json_db_body[0]==','):
        json_db_body=json_db_body[1:]
    
    db_body=""" {
       "widgets": ["""+json_db_body+"""]
       }
       """    

    #print(db_body)
    print(nombreDashboard)
    responsePutDashboard = monitoringCloudwatchClient.put_dashboard(
        DashboardName=nombreDashboard,
        DashboardBody=db_body
    )    
    
