import json
import boto3
import time
import csv
import sys
import shutil
import os
from aux_functions import aux_functions, list_all_alb_tg



    


def alb_tg_string_TargetResponseTime(dict_values):
    """It creates CloudWatch widget string to CloudWatch Dashboard of ALB and TG metric: TargetResponseTime. The data from ALB and TG is obtained from function: list_all_alb_tg.createList_Alb_vs_TG
    
    Parameters
    ----------
    dict_values : str
        Dictionary with the values that it will be used to update cloudwatch dashboard
    
    Returns
    -------
    Str
        String with the widget of ALB and TG metric: TargetResponseTime
    """
    nombreMetrica='TargetResponseTime'
    cluster=dict_values['cluster']
    entorno=dict_values['entorno']
    name=dict_values['name']
    apps=dict_values['apps']
    account=dict_values['account']
    existsTag_GroupComponentGrouping=dict_values['existsTag_GroupComponentGrouping']
    instanceEC2 = dict_values['instanceEC2']
    
    list_Alb_vs_TG = list_all_alb_tg.createList_Alb_vs_TG(dict_values)
    if (len(list_Alb_vs_TG)==0):
      stringWidgetTargetResponseTime=""
      
    else:

    #if len(list_Alb_vs_TG) > 0:
      i=0
      #with open(nombreFichero, newline='') as csvfile:

      cadenaCompleta=""
      print('Widgets TargetResponseTime - ALB - TG que se van a crear: '+str(len(list_Alb_vs_TG)))
      for row in list_Alb_vs_TG:
          
          i=i+1
          cadena=""
          cadena=cadena+"""["AWS/ApplicationELB", "TargetResponseTime" """ 
          cadena=cadena+""", "TargetGroup", """+aux_functions.add_quote(row['tg_name'])
          cadena=cadena+""", "LoadBalancer","""+aux_functions.add_quote(row['alb_name'])
          cadena=cadena+""", { "accountId" : """+aux_functions.add_quote(account)
          cadena=cadena+""", "label" : """
          cadena=cadena+aux_functions.add_quote("TG ("+row['tg_corto']+")- ALB: "+row['alb_corto'])
          if (i<len(list_Alb_vs_TG)):
            cadena=cadena+"}],"""
          else:  
            cadena=cadena+"}]"""
          cadenaCompleta=cadenaCompleta+cadena
        #print(cadenaCompleta)
    
      stringWidgetTargetResponseTime ="""{
            "height": 6,
            "width": 12,
            "x": 0,
            "y": 6,
            "type": "metric",
            "properties": {
                "metrics": ["""
      stringWidgetTargetResponseTime =stringWidgetTargetResponseTime+cadenaCompleta
      stringWidgetTargetResponseTime =stringWidgetTargetResponseTime+"""],
                "region": "eu-west-1",
                "stacked": false,
                "title": "ALB - TG - TargetResponseTime",
                "view": "timeSeries",
                "stacked" : true
            }
        }"""     
        

    #print(stringWidgetTargetResponseTime)
    return(stringWidgetTargetResponseTime)
    
    
def alb_tg_string_UnHealthyHostCount(dict_values):
    """It creates CloudWatch widget string to CloudWatch Dashboard of ALB and TG metric: UnHealthyHostCount. The data from ALB and TG is obtained from function: list_all_alb_tg.createList_Alb_vs_TG
    
    Parameters
    ----------
    dict_values : str
        Dictionary with the values that it will be used to update cloudwatch dashboard
    
    Returns
    -------
    Str
        String with the widget of ALB and TG metric: UnHealthyHostCount
    """
    nombreMetrica='UnHealthyHostCount'
    cluster=dict_values['cluster']
    entorno=dict_values['entorno']
    name=dict_values['name']
    apps=dict_values['apps']
    account=dict_values['account']
    existsTag_GroupComponentGrouping=dict_values['existsTag_GroupComponentGrouping']
    instanceEC2 = dict_values['instanceEC2']
    
    list_Alb_vs_TG = list_all_alb_tg.createList_Alb_vs_TG(dict_values)
    
    if (len(list_Alb_vs_TG)==0):
      stringWidgetUnHealthyHostCount=""
      
    else:

    #if len(list_Alb_vs_TG) > 0:
      i=0
      #with open(nombreFichero, newline='') as csvfile:

      cadenaCompleta=""
      print('Widgets UnHealthyHostCount - ALB - TG que se van a crear: '+str(len(list_Alb_vs_TG)))
      for row in list_Alb_vs_TG:
          
          i=i+1
          cadena=""
          cadena=cadena+"""["AWS/ApplicationELB", "UnHealthyHostCount" """ 
          cadena=cadena+""", "TargetGroup", """+aux_functions.add_quote(row['tg_name'])
          cadena=cadena+""", "LoadBalancer","""+aux_functions.add_quote(row['alb_name'])
          cadena=cadena+""", { "accountId" : """+aux_functions.add_quote(account)
          cadena=cadena+""", "label" : """
          cadena=cadena+aux_functions.add_quote("TG ("+row['tg_corto']+")- ALB: "+row['alb_corto'])
          if (i<len(list_Alb_vs_TG)):
            cadena=cadena+"}],"""
          else:  
            cadena=cadena+"}]"""
          cadenaCompleta=cadenaCompleta+cadena
        #print(cadenaCompleta)
    
      stringWidgetUnHealthyHostCount ="""{
            "height": 6,
            "width": 12,
            "x": 0,
            "y": 6,
            "type": "metric",
            "properties": {
                "metrics": ["""
      stringWidgetUnHealthyHostCount =stringWidgetUnHealthyHostCount+cadenaCompleta
      stringWidgetUnHealthyHostCount =stringWidgetUnHealthyHostCount+"""],
                "region": "eu-west-1",
                "stacked": false,
                "title": "ALB - TG - UnHealthyHostCount",
                "view": "singleValue"
            }
        }"""     
        

    #print(stringWidgetUnHealthyHostCount)
    return(stringWidgetUnHealthyHostCount)
    
    
def alb_tg_string_HTTPCode_Target_5XX_Count(dict_values):
    """It creates CloudWatch widget string to CloudWatch Dashboard of ALB and TG metric: HTTPCode_Target_5XX_Count. The data from ALB and TG is obtained from function: list_all_alb_tg.createList_Alb_vs_TG
    
    Parameters
    ----------
    dict_values : str
        Dictionary with the values that it will be used to update cloudwatch dashboard
    
    Returns
    -------
    Str
        String with the widget of ALB and TG metric: HTTPCode_Target_5XX_Count
    """
    nombreMetrica='HTTPCode_Target_5XX_Count'
    cluster=dict_values['cluster']
    entorno=dict_values['entorno']
    name=dict_values['name']
    apps=dict_values['apps']
    account=dict_values['account']
    existsTag_GroupComponentGrouping=dict_values['existsTag_GroupComponentGrouping']
    instanceEC2 = dict_values['instanceEC2']
    
    list_Alb_vs_TG = list_all_alb_tg.createList_Alb_vs_TG(dict_values)
    
    if (len(list_Alb_vs_TG)==0):
      cadenaCompleta=""
      
    else:
        i=0
        cadenaCompleta=""
        print('Widgets HTTPCode_Target_5XX_Count - ALB - TG que se van a crear: '+str(len(list_Alb_vs_TG)))
        for row in list_Alb_vs_TG:
          
          i=i+1
          #print(dict_values_instance['name']+" ("+dict_values_instance['instanceEC2']+")")
          cadena=""
          cadena=cadena+"""["AWS/ApplicationELB", "HTTPCode_Target_5XX_Count" """
          cadena=cadena+""", "TargetGroup", """+aux_functions.add_quote(row['tg_name'])
          cadena=cadena+""", "LoadBalancer","""+aux_functions.add_quote(row['alb_name'])
          cadena=cadena+""", { "accountId" : """+aux_functions.add_quote(account)
          cadena=cadena+""", "label" : """
          cadena=cadena+aux_functions.add_quote("TG ("+row['tg_corto']+")")+"}]"
          #cadenaCompleta=cadenaCompleta+cadena
          stringWidgetHTTPCodeTarget5XXCount="""{
            "height": 6,
            "width": 12,
            "x": 0,
            "y": 6,
            "type": "metric",
            "properties": {
                "metrics": ["""
          stringWidgetHTTPCodeTarget5XXCount=stringWidgetHTTPCodeTarget5XXCount+cadena
          stringWidgetHTTPCodeTarget5XXCount=stringWidgetHTTPCodeTarget5XXCount+"""],
                "region": "eu-west-1",
                "stacked": false,
                "title": "HTTPCode_Target_5XX_Count ALB: """+row['alb_corto']+""" ",
                "view": "timeSeries"
            }
          }"""
          if (i<len(list_Alb_vs_TG)):
            stringWidgetHTTPCodeTarget5XXCount=stringWidgetHTTPCodeTarget5XXCount+","
          cadenaCompleta=cadenaCompleta+stringWidgetHTTPCodeTarget5XXCount
    #print(cadenaCompleta)
    return(cadenaCompleta)